import { ApplicationConfig, importProvidersFrom } from '@angular/core';
import { provideRouter } from '@angular/router';
import { HttpClientJsonpModule, HttpClientModule, HttpClientXsrfModule } from '@angular/common/http';
import { routes } from './app.routes';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { HttpErrorHandler } from './http-error-handler.service';
import { MessageService } from './message.service';
import { provideProtractorTestingSupport } from '@angular/platform-browser';

export const appConfig: ApplicationConfig = {
  providers: [
	  provideRouter(routes), 
	  provideAnimationsAsync(),  
	  importProvidersFrom(HttpClientModule),
	  importProvidersFrom(HttpClientJsonpModule),
	  importProvidersFrom(
        HttpClientXsrfModule.withOptions({
        cookieName: 'My-Xsrf-Cookie',
        headerName: 'My-Xsrf-Header',
      })
    ),
	  HttpErrorHandler,
	  MessageService,
	  provideProtractorTestingSupport(), // essential for e2e testing
	  ]
};


