export interface BannerApiRequest {
}
