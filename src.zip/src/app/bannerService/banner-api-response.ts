export interface BannerApiResponse {
}
