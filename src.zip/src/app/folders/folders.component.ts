import {Component, OnInit} from '@angular/core';
import {MatDividerModule} from '@angular/material/divider';
import {MatIconModule} from '@angular/material/icon';
import {DatePipe} from '@angular/common';
import {MatListModule} from '@angular/material/list';
import {MatBadgeModule} from '@angular/material/badge';
import {FoldersApiService } from '../folderService/folders-api.service';
import {MatButtonToggleModule} from '@angular/material/button-toggle';
import {CommonModule } from '@angular/common';  
import { ActivatedRoute } from '@angular/router';
import { Router , NavigationExtras } from '@angular/router';
import { RouterModule } from '@angular/router';
import { LoginApiService } from '../logicService/login-api.service';

export interface Section {
  name: string;
  updated: Date;
}

@Component({
  selector: 'app-folders',
  styleUrl: './folders.component.css',
  templateUrl: './folders.component.html',
  standalone: true,
  imports: [CommonModule,MatListModule, MatIconModule, MatDividerModule, DatePipe,MatBadgeModule,MatButtonToggleModule,RouterModule],

  
})
export class FoldersComponent implements OnInit{
    
    currentFolder:string = 'INBOX' ;

    folders: Section[] = [] ;
	constructor(private foldersApiService: FoldersApiService , private loginApiService: LoginApiService , private route: ActivatedRoute ,   private router: Router  ) { 
		
	}
    ngOnInit(): void {
		let folder = this.route.snapshot.queryParamMap.get('folder');
		if(folder === '' || folder == null ) this.currentFolder = 'INBOX' ;
		else this.currentFolder = folder ;     
		
		this.foldersApiService.getAllFolderList().subscribe(folderResponse => {

		for (let i = 0; i < folderResponse.length; i++) {
			  console.log(folderResponse[i].name);
			   this.folders.push({
			      name: folderResponse[i].name,
			      updated: new Date(),
			    })
			}

      })
        
    }
	
/*	 folders: Section[] = [
    {
      name: 'Photos',
      updated: new Date('1/1/16'),
    },
    {
      name: 'Recipes',
      updated: new Date('1/17/16'),
    },
    {
      name: 'Work',
      updated: new Date('1/28/16'),
    },
  ]*/;
  
  notes: Section[] = [
    {
      name: 'Vacation Itinerary',
      updated: new Date('2/20/16'),
    },
    {
      name: 'Kitchen Remodel',
      updated: new Date('1/18/16'),
    },
  ];
  
  getUserName(): string {
  	return this.loginApiService.getUserName() ;
  }
  
  getFolderName(): string {
		return this.currentFolder;
	}

  setFolderName(folderName: string) {
		this.currentFolder = folderName ;
		this.router.navigateByUrl('/', { skipLocationChange: true }).then(() => {
			this.router.navigate(
			    ['/app'],
			    { queryParams: { folder: folderName } }
			  )

		});
		
	}



}
