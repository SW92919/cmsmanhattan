import { Component } from '@angular/core';
import {MatGridListModule} from '@angular/material/grid-list';
import { BannerComponent } from '../banner/banner.component';
import { FoldersComponent } from '../folders/folders.component';
import { MessageListComponent } from '../message-list/message-list.component';
import { RouterOutlet } from '@angular/router';
import {DomSanitizer} from '@angular/platform-browser';
import {MatIconRegistry, MatIconModule} from '@angular/material/icon';


const EXIT_ICON =  
'<svg class="w-[20px] h-[20px] text-gray-800 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">' +
  ' <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.7" d="M18 14v4.833A1.166 1.166 0 0 1 16.833 20H5.167A1.167 1.167 0 0 1 4 18.833V7.167A1.166 1.166 0 0 1 5.167 6h4.618m4.447-2H20v5.768m-7.889 2.121 7.778-7.778"/>' + 
'</svg>';


@Component({
  selector: 'app-layout',
  standalone: true,
  imports: [MatIconModule,MatGridListModule,FoldersComponent ,MessageListComponent ,BannerComponent,RouterOutlet],
  templateUrl: './layout.component.html',
  styleUrl: './layout.component.css'
})
export class LayoutComponent {
	
	constructor(iconRegistry: MatIconRegistry, sanitizer: DomSanitizer) {
    // Note that we provide the icon here as a string literal here due to a limitation in
    // Stackblitz. If you want to provide the icon from a URL, you can use:
    // `iconRegistry.addSvgIcon('thumbs-up', sanitizer.bypassSecurityTrustResourceUrl('icon.svg'));`
    //iconRegistry.addSvgIconLiteral('thumbs-up', sanitizer.bypassSecurityTrustHtml(THUMBUP_ICON));
    iconRegistry.addSvgIconLiteral('exit', sanitizer.bypassSecurityTrustHtml(EXIT_ICON));
  }

logOut()
{
	
}

}
