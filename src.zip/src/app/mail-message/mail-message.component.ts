import { AfterViewInit, Component, ElementRef, inject, Input, OnInit, ViewChild, NgZone, OnDestroy, EventEmitter, Output } from '@angular/core';


import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatSelectModule } from '@angular/material/select';
import { MatRadioModule } from '@angular/material/radio';
import { MatCardModule } from '@angular/material/card';
import { MessageDataApiService } from '../messageDataService/message-data-api.service';
import { MatDividerModule } from '@angular/material/divider';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatFormFieldModule } from '@angular/material/form-field';
import { Editor, NgxEditorModule } from 'ngx-editor';
import { SendApiService } from '../sendService/send-api.service';
import { MailMessageSendRequest } from '../sendService/new-message-api-request';
import { FileUploadComponent } from '../file-upload/file-upload.component';
import { FileDisplayComponent } from '../file-display/file-display.component';
import { MatIconModule} from '@angular/material/icon';
import { FileItem } from '../messageDataService/mail-message-api-response';

@Component({
	selector: 'app-mail-message',
	standalone: true,
	imports: [
		MatInputModule,
		MatButtonModule,
		MatSelectModule,
		MatRadioModule,
		MatCardModule,
		ReactiveFormsModule,
		MatDividerModule,
		MatButtonToggleModule,
		MatFormFieldModule,
		NgxEditorModule,
		FileDisplayComponent,
		FileUploadComponent,
		MatIconModule

	],
	templateUrl: './mail-message.component.html',
	styleUrl: './mail-message.component.css'
})
export class MailMessageComponent implements OnInit {

	@Input() messageNumber: number = 0;
	@Input() folder: string = '';
    files:string[] = [] ;
	@Output() removeTab = new EventEmitter();
	
	closeTab() {
	    this.removeTab.emit();
	  }


	editor!: Editor;
	html = '';


	@ViewChild('body') body!: ElementRef;
	@ViewChild('from') from!: ElementRef;
	@ViewChild('to') to!: ElementRef;
	@ViewChild('cc') cc!: ElementRef;
	@ViewChild('bcc') bcc!: ElementRef;
	@ViewChild('subject') subject!: ElementRef;
	@ViewChild('receivedDate') receivedDate!: ElementRef;


	constructor(private messageDataApiService: MessageDataApiService, private sendApiService: SendApiService) { }


	ngOnInit(): void {
		this.editor = new Editor();
		this.messageDataApiService.getMessage({
			folder: this.folder,
			messageNumber: this.messageNumber,
			renderingType: 1
		}).subscribe(messageContentResponse => {

			this.addressForm.setValue({
				to: messageContentResponse.mailMessage.to,
				from: messageContentResponse.mailMessage.from,
				cc: messageContentResponse.mailMessage.cc,
				bcc: messageContentResponse.mailMessage.bcc,
				subject: messageContentResponse.mailMessage.subject,
				body: messageContentResponse.mailMessage.body,
				receivedDate: messageContentResponse.mailMessage.receivedDate,
				shipping: null
			});
			this.body.nativeElement.innerHTML = messageContentResponse.mailMessage.body;
			this.to.nativeElement.innerHTML = "To: " + messageContentResponse.mailMessage.to;
			this.from.nativeElement.innerHTML = "From: " + messageContentResponse.mailMessage.from  ;
			// this.cc.nativeElement.innerHTML  = messageContentResponse.mailMessage.cc  ;
			// this.bcc.nativeElement.innerHTML  = messageContentResponse.mailMessage.bcc  ;
			this.subject.nativeElement.innerHTML = "Subject: " + messageContentResponse.mailMessage.subject;
			//  this.receivedDate.nativeElement.innerHTML  = messageContentResponse.mailMessage.receivedDate  ;
			if (this.messageNumber === 0) this.addNewMessage();
		})
	}




	private fb = inject(FormBuilder);
	addressForm = this.fb.group({
		from: "",
		to: "",
		cc: "",
		bcc: "",
		subject: "",
		body: "",
		receivedDate: "",
		shipping: ['free', Validators.required]
	});

	hasBcc = false;
	hasCc = false;
	hasTo = false;
	hasSubject = false;
	hasBody = false;
	hasSubmitButton = false;
	hasPriorityButton = false;
	showSendFields = false;
	showUploadFile = false ;



	
	covertToAttachment( file:string[] ): FileItem[]{
		
		let attachment = file.map(val => ({
		    contentType  : '',
			fileName  : val,
			file  : null,
			charset  : '',
			saved: false
		}));
		
		return attachment as any ;
	}

	onSubmit(): void {

		this.sendApiService.sendMail({
			messageNumber: "",
			to: this.addressForm.get('to')?.value as string,
			from: this.addressForm.get('from')?.value as string,
			cc: this.addressForm.get('cc')?.value as string,
			bcc: this.addressForm.get('bcc')?.value as string,
			subject: this.addressForm.get('subject')?.value as string,
			body: this.addressForm.get('body')?.value as string,
			receivedDate: this.addressForm.get('receivedDate')?.value as string,
			html:true,
			attachment: this.covertToAttachment(this.files) 
		}).subscribe(response => {
			console.log("sent subkect:  " + + response);
			this.saveMessage();
			this.closeTab();
		})


	}

	addNewMessage(): void {

		this.addressForm.setValue({
			to: '',
			from: this.getUserName(),
			cc: '',
			bcc: '',
			subject: '',
			body: '',
			receivedDate: '',
			shipping: null
		});

		this.hasTo = true;
		this.hasSubject = true;
		this.hasBody = true;
		this.hasSubmitButton = true;
		this.hasPriorityButton = true;
		this.showSendFields = true;
	}

	replyMessage(): void {
		
		let to:string = this.addressForm.get('from')?.value as string ;
	    let from:string = this.addressForm.get('to')?.value as string ;
		let subject:string = "Re: " + this.addressForm.get('subject')?.value as string;
		let body:string =  "<br/><br/>  -----Original Message-----" + 
		  "<br/> From: " +  this.addressForm.get('from')?.value  +
		  "<br/> To: " +  this.addressForm.get('to')?.value  +
		  "<br/> subject: " + this.addressForm.get('subject')?.value +
		  "<br/> " + this.addressForm.get('body')?.value as string


		this.addressForm.setValue({
			to: to,
			from: from,
			cc: this.addressForm.get('cc')?.value as string ,
			bcc: this.addressForm.get('bcc')?.value as string ,
			subject: subject ,
			body: body,
			receivedDate: '',
			shipping: null
		});

		
		this.to.nativeElement.innerHTML = "To: " +to ;
		this.from.nativeElement.innerHTML = "From: " +from ;
		this.subject.nativeElement.innerHTML = "Subject: " + subject;
		this.body.nativeElement.innerHTML = body ;
		
		this.hasTo = true;
		this.hasSubject = true;
		this.hasBody = true;
		this.hasSubmitButton = true;
		this.hasPriorityButton = true;
		this.showSendFields = true;
	}


	forwardMessage(): void {
		//let to:string = this.addressForm.get('from')?.value as string ;
	    let from:string = this.addressForm.get('to')?.value as string ;
		let subject:string = "Re: " + this.addressForm.get('subject')?.value as string;
		let body:string =  "<br/><br/>  -----Original Message-----" + 
		  "<br/> From: " +  this.addressForm.get('from')?.value  +
		  "<br/> To: " +  this.addressForm.get('to')?.value  +
		  "<br/> subject: " + this.addressForm.get('subject')?.value +
		  "<br/> " + this.addressForm.get('body')?.value as string


		this.addressForm.setValue({
			to: '',
			from: from,
			cc: '' ,
			bcc: '' ,
			subject: subject ,
			body: body,
			receivedDate: '',
			shipping: null
		});

		
		this.to.nativeElement.innerHTML = "To: "  ;
		this.from.nativeElement.innerHTML = "From: " +from ;
		this.subject.nativeElement.innerHTML = "Subject: " + subject;
		this.body.nativeElement.innerHTML = body ;
		
		this.hasTo = true;
		this.hasSubject = true;
		this.hasBody = true;
		this.hasSubmitButton = true;
		this.hasPriorityButton = true;
		this.showSendFields = true;
	}

	saveMessage(): void {
		this.hasTo = false;
		this.hasCc = false;
		this.hasBcc = false;
		this.hasSubject = false;
		this.hasBody = false;
		this.hasSubmitButton = false;
		this.hasPriorityButton = false;
		this.showSendFields = false;
		this.ngOnInit();
	}

	deleteMessage(): void {
		alert('Are you sure delete the message ?');
	}

	moveMessage(): void {
		alert('Are you sure move the message ?');
	}

	attachFile()
	{
	this.showUploadFile = true ;
	}

    uploadedFile( fileName: string ){
		this.files.push(fileName);
		this.showUploadFile = false ;
		//this.files.length
	}


	getUserName(): string {
		return <string>sessionStorage.getItem('userName');
	}
	
	toggleChange(event:any) {
	    const toggle = event.source;
	    //if (toggle && event.value.some(item => item == toggle.value)) {
	        toggle.buttonToggleGroup.value = [toggle.value];
	   // }
	}

}
