import { AfterViewInit, Component, EventEmitter, OnInit, Output, ViewChild } from '@angular/core';
import { MatTableModule, MatTable , MatTableDataSource} from '@angular/material/table';
import { MatPaginatorModule, MatPaginator, PageEvent } from '@angular/material/paginator';
import { MatSortModule, MatSort } from '@angular/material/sort';
import { MessageListDataSource, MessageListItem } from './message-list-datasource';
import {MatCardModule} from '@angular/material/card';

import { MatCheckboxModule} from '@angular/material/checkbox';
import { SelectionModel} from '@angular/cdk/collections';

import { MatTabsModule} from '@angular/material/tabs';
import { MatButtonToggleModule} from '@angular/material/button-toggle';

import { MailMessageComponent } from '../mail-message/mail-message.component';
import { ActivatedRoute } from '@angular/router';
import { MessageListApiService } from '../messageListService/message-list-api.service';
import { DeleteMessageRequest, MessageListRequest, MoveMessageRequest, SearchMessageRequest } from '../messageListService/message-list-api-request';
import { FormControl } from '@angular/forms';
import { MatDividerModule} from '@angular/material/divider';
import { MatIconModule} from '@angular/material/icon';
import {Router} from '@angular/router';
import { CommonModule } from '@angular/common';  
import { DialogMoveMessagesComponent } from '../dialog-move-messages/dialog-move-messages.component';
import { UtilsApiService } from '../utilsService/utils-api.service';

export interface PeriodicElement {
  name: string;
  position: number;
  weight: number;
  symbol: string;
}



@Component({
  selector: 'app-message-list',
  templateUrl: './message-list.component.html',
  styleUrl: './message-list.component.css',
  standalone: true,
  imports: [DialogMoveMessagesComponent,CommonModule,MatIconModule ,MatTableModule, MatPaginatorModule, MatSortModule,MatCardModule,MatCheckboxModule,MatTabsModule,MatButtonToggleModule,MailMessageComponent,MatDividerModule]
})
export class MessageListComponent implements AfterViewInit   {
	
  currentFolder:string = '' ;
  currentMsgId:number = 0 ;
  tabs = ['Messages'];
  selected = new FormControl(0); 
  tabInex:number = 0 ;

  	
   constructor(private route: ActivatedRoute , private messageListApiService: MessageListApiService , private  utilsApiService: UtilsApiService , private router: Router){}
   
  
 

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  @ViewChild(MatTable) table!: MatTable<MessageListItem>;
  dataSource = new MessageListDataSource();

  /** Columns displayed in the table. Columns IDs can be added, removed, or reordered. */
  displayedColumns: string[] = ['id', 'name','receivedDate','size','attachment'];
  //dataSource = new MatTableDataSource<PeriodicElement>(ELEMENT_DATA);
  selection = new SelectionModel<PeriodicElement>(true, []);
  
  length = 50;
  pageSize = 20;
  pageIndex = 0;
  pageSizeOptions = [20, 40, 60];

  
  ngAfterViewInit(): void {
   
    
     let folder = this.route.snapshot.queryParamMap.get('folder');
     if(folder === '' || folder == null ) folder = 'INBOX' ;
     this.currentFolder = folder as string ;
     this.dataSource.data = [] ;
     this.utilsApiService.getMessageCount(folder).subscribe(response => {
		 this.length = Number(response);
		 let startMsgNumber = (this.pageIndex * this.pageSize) + 1 ; 
		 let lastMsgNumber = (this.pageIndex * this.pageSize)  + this.pageSize  ;
		 if ( lastMsgNumber > this.length ) lastMsgNumber = this.length ;
		 this.messageListApiService.listMessages(
			{
				startMsgNumber:startMsgNumber , 
				lastMsgNumber:lastMsgNumber ,
				folder:""+folder
			}
			).subscribe(messageListResponse => {
			  for (let i = 0; i < messageListResponse.messageList.length; i++) {
			  console.log(messageListResponse.messageList[i]);
			  this.dataSource.data.push({
			      id:  Number(messageListResponse.messageList[i].messageNumber),
			      name:  messageListResponse.messageList[i].subject,
			      receivedDate:  messageListResponse.messageList[i].receivedDate,
			      attachment:  messageListResponse.messageList[i].attachment != null && messageListResponse.messageList[i].attachment.length > 0  ,
			      size:  messageListResponse.messageList[i].size,
			      status:messageListResponse.messageList[i].status,
			      priority:'nornal'
			    })
			}
			
			 this.dataSource.sort = this.sort;
			 this.dataSource.paginator = this.paginator;
			 this.table.dataSource = this.dataSource;

      })
	 })
     

      
      
   
  }
  

  
  handlePageEvent(event: PageEvent) {
    this.length = event.length;
    this.pageSize = event.pageSize;
    this.pageIndex = event.pageIndex;
    
		 let startMsgNumber = (this.pageIndex * this.pageSize) + 1 ; 
		 let lastMsgNumber = (this.pageIndex * this.pageSize)  + this.pageSize  ;
		 if ( lastMsgNumber > this.length ) lastMsgNumber = this.length ;
		 this.messageListApiService.listMessages(
			{
				startMsgNumber:startMsgNumber , 
				lastMsgNumber:lastMsgNumber ,
				folder:this.currentFolder
			}
			).subscribe(messageListResponse => {
				this.dataSource.data = [] ;	
				for (let i = 0; i < messageListResponse.messageList.length; i++) {
					  console.log(messageListResponse.messageList[i]);
					  this.dataSource.data.push({
					      id:  Number(messageListResponse.messageList[i].messageNumber),
					      name:  messageListResponse.messageList[i].subject,
					      receivedDate:  messageListResponse.messageList[i].receivedDate,
					      attachment:  messageListResponse.messageList[i].attachment != null && messageListResponse.messageList[i].attachment.length > 0  ,
					      size:  messageListResponse.messageList[i].size,
					      status:messageListResponse.messageList[i].status,
					      priority:'nornal'
					    })
					}
					 this.dataSource.sort = this.sort;
					 this.dataSource.paginator = this.paginator;
					 this.table.dataSource = this.dataSource;
		      })
      
  }
  

  
  
  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  toggleAllRows() {
    if (this.isAllSelected()) {
      this.selection.clear();
      return;
    }

   //this.selection.select(...this.dataSource.data); //?
  }

  /** The label for the checkbox on the passed row */
  checkboxLabel(row?: PeriodicElement): string {
    if (!row) {
      return `${this.isAllSelected() ? 'deselect' : 'select'} all`;
    }
    return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${row.position + 1}`;
  }
  
  
  
/*  addTab(selectAfterAdding: boolean, tabName: string ) {
    this.tabs.push(tabName);
    if (selectAfterAdding) {
    this.selected.setValue(this.tabs.length - 1);
    }
  }*/

 addNewTab(tabName: string ) {
	this.currentMsgId = -1 ; 
    this.tabs.push(tabName);
    this.selected.setValue(this.tabs.length - 1);
    this.currentMsgId = 0 ;

  }


 addTab( currentMsgId: number  ,  tabName: string ) {
	this.currentMsgId = currentMsgId ; 
    this.tabs.push(tabName);
    this.selected.setValue(this.tabs.length - 1);

  }

  removeTab(index: number) {
    this.tabs.splice(index, 1);
    this.selected.setValue(index);

  }


 
 
  deleteMessages()
 {
	
	let rows:MessageListItem[]  = this.selection.selected as [] ;
    let selected:string[] = new Array(rows.length);
 	rows.forEach((val, i) => {
	//this.removeRow(val);
     selected[i] = "" + val.id ;
 	})
	// this.table.renderRows();
	this.messageListApiService.deleteMessage({
	folder:this.currentFolder,
	message:selected
	}).subscribe(response => {
				console.log("deleteMessages return:  " +   + response) ;
				   this.selection.clear();
  				   this.ngAfterViewInit();
				   this.table.renderRows();
				 })
 }
 
 
 removeRow(doc:MessageListItem){
   this.dataSource.data.forEach( (item, index) => {
     if(item.id === doc.id) this.dataSource.data.splice(index,1);
   });
}
 
 moveMessages()
 {

	this.messageListApiService.deleteMessage({
	folder:this.currentFolder,
	message:this.selection.selected as []
	}).subscribe(response => {
				console.log("deleteMessages return:  " +   + response) ;
				this.ngAfterViewInit();
				this.table.renderRows();
			})
     
 }
 
 
 toggleChange(event:any) {
     const toggle = event.source;
     //if (toggle && event.value.some(item => item == toggle.value)) {
         toggle.buttonToggleGroup.value = [toggle.value];
    // }
 }
 

 
  
}

