export interface NewMessageApiResponse {
}
